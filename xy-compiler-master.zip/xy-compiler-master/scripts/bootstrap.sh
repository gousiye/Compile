#!/bin/bash

sudo apt-get update
sudo apt-get install -y git build-essential flex bison llvm-10* libedit-dev zlib1g-dev