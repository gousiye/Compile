#ifndef FA70C9C5_E371_4F29_83E8_04D0469AB8EF
#define FA70C9C5_E371_4F29_83E8_04D0469AB8EF

#include <libxy/exports.h>

#ifdef __cplusplus
extern "C" {
#endif

LIB_XY_EXPORTS void printi(long long val);

#ifdef __cplusplus
}
#endif

#endif /* FA70C9C5_E371_4F29_83E8_04D0469AB8EF */
