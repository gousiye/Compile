#include <cstdio>

#include <libxy/system/console/printi.h>

LIB_XY_EXPORTS void printi(long long val) { printf("%lld\n", val); }